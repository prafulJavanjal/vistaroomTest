<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\JobDetailsModel;

class Home extends Controller
{
	public function index()
	{
		return view('job_list');
	}

	public function fetchJobList($pageNo)
	{
		if ($this->request->isAJAX()){

			$responce = ['ack' => 'success'];
			$pageNo = (int) $pageNo;

			if (!empty($pageNo) && $pageNo > 0) {
				$modelObj = new JobDetailsModel();
				$data = $modelObj->getRows($pageNo);

				if (!empty($data['error'])) {
					$responce['ack'] = 'error';
					$responce['error'] = $data['errorMessage'];
				} 
				else {
					$jobList = [];

					foreach ($data['data'] as $key => $val) {
						$job 				= [];
						$val				= (array) $val;

						$job['id'] 			= $val['id'];
						$job['company'] 	= $val['company_name'];
						$job['location'] 	= $val['location'];
						$job['logoUrl'] 	= $val['logo_url'];
						$job['title'] 		= $val['title'];
						$job['date'] 		= $val['updated_at'];

						$jobList[] = $job;
					}

					$responce['data'] = $jobList;
				}
			} 
			else {
				$responce['ack'] = 'error';
				$responce['error'] = 'Please use interger page no minimum 1';
			}

	      	return json_encode($responce);
		} else {
		   exit('No direct script access allowed');
		}
	}

	public function getJobDetails($jobId)
	{
		if ($this->request->isAJAX()){

			$responce = ['ack' => 'success'];
			$jobId = (int) $jobId;

			if (!empty($jobId) && $jobId > 0) {
				$modelObj = new JobDetailsModel();
				$data = $modelObj->getJobDetail($jobId);

				if (!empty($data['error'])) {
					$responce['ack'] = 'error';
					$responce['error'] = $data['errorMessage'];
				} 
				else {
					$jobInfo = [];

					if (!empty($data['data'][0])) {
						$jobInfo 				= [];
						$val					= (array) $data['data'][0];

						$jobInfo['title'] 		= $val['title'];
						$jobInfo['company'] 	= $val['company_name'];
						$jobInfo['location'] 	= $val['location'];
						$jobInfo['content'] 	= $val['content'];
					}

					$responce['data'] = $jobInfo;
				}
			} 
			else {
				$responce['ack'] = 'error';
				$responce['error'] = 'Please use interger job id';
			}

	      	return json_encode($responce);
		} else {
		   exit('No direct script access allowed');
		}
	}
}
