<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Vistaroom Test</title>
	<meta name="description" content="Vistaroom Test">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/style.css'); ?>">

</head>
<body>
 <h1>Job List</h1>
    <div class="container" id="container">
        <div class="list" id="jobList">
            <div id="listContainer">
                <div class='loader' id='loaderDiv'><img src="<?php echo base_url('css/loading.gif'); ?>" width="30px";></div>
            </div>
        </div>
        <div class="details" id="jobDetails">
        	<div style="text-align: center;"><br><br><img src="<?php echo base_url('css/bg.png'); ?>"></div>
        </div>
        <div style="clear:both"></div>
    </div>
    <div style="text-align: center;">Test submited by <b>Praful Javanjal</b></div>

    <!--  script file load in footer -->
    <script type="text/javascript">
    	var baseUrl = "<?php echo base_url(); ?>";
    </script>
 	<script src="<?php echo base_url('js/jquery.min.js'); ?>"></script>
 	<script src="<?php echo base_url('js/script.js'); ?>"></script>

</body>
</html>
