<?php 
namespace App\Models;
use CodeIgniter\Model;

class JobDetailsModel extends Model
{
    protected $table = 'jobDetails';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'email'];

    function getRows($pageNo = 1, $count = 10) {
		try {
	    	$rowLimit = $count;
	    	$offSet = ($pageNo - 1) * $rowLimit;

			$sqlQuery = "SELECT id, logo_url, title, company_name, location, updated_at FROM ". $this->table ." LIMIT ?, ?";
			$result = $this->db->query($sqlQuery, [$offSet, $rowLimit])->getResult();

	    	return ['error' => false, 'data' => $result];
	    } catch (Exception $e) {
		    
            // throw $e;
	    	return ['error' => true, 'errorMessage' => $e->getMessage()];
	    }    
    }

    function getJobDetail($jobId) {

    	if (empty($jobId) || $jobId <= 0) {
    		return ['error' => true, 'errorMessage' => 'Empty job id'];
    	}

		try {
			$sqlQuery = "SELECT title, company_name, location, content FROM ". $this->table ." WHERE id=?";
			$result = $this->db->query($sqlQuery, [$jobId])->getResult();

	    	return ['error' => false, 'data' => $result];
	    } catch (Exception $e) {
		    
            // throw $e;
	    	return ['error' => true, 'errorMessage' => $e->getMessage()];
	    }    
    }

}