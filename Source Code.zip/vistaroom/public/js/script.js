var pageNo = 1;
var callListAjax = true;
$(document).ready(function(){
    
    function getDetails(event) {
        let rowId = $(this).attr('rowId');

        if (rowId > 0) {
            $("#jobDetails").html('<div style="text-align:center"><img src="http://vistatest.com/css/loading.gif" width="50px" ;=""></div>');
            var getUrl = baseUrl + "/getJob/"+rowId+"/detail";

            $.ajax({
                url: getUrl,
                type: 'get',
                data: {},
                success: function(res){
                    if ($.trim(res) != '') {

                        let result = $.parseJSON(res);
                        if (typeof(result) == 'object' && result.ack == "success") {
                                let htmlStr = '';
                                let content = jQuery('<div />').html(result.data.content).text();

                                htmlStr += "<div class='title'>" + result.data.title +"</div>";
                                htmlStr += "<div class='company'><b>" + result.data.company +"</b>   &nbsp; " + result.data.location +"</div>";
                                htmlStr += content +"<br>";

                                $("#jobDetails").html(htmlStr);
                                // $("#jobDetails").html($.parseHTML(htmlContent));
                        } else {
                            alert('Error occured, please try afer sometime');
                        }
                    }
                },
                complete: function(response){

                },
                error: function(response){
                    $("#jobDetails").html('<div class="details" id="jobDetails"><div style="text-align: center;"><br><br><img src="css/bg.png"></div></div>');
                }
            });
        }
    }

    function ajaxCall(pNo) {
        $('#loaderDiv').show();
        var url = baseUrl+"/getJobList/"+pNo;

        $.ajax({
            url: url,
            type: 'get',
            data: {},
            beforeSend: function () {
                callListAjax = false;
                console.log("callListAjax in before" + callListAjax);
            },
            success: function(response){
                if ($.trim(response) != '') {
                    let result = $.parseJSON(response);
                    if (typeof(result) == 'object' && result.ack == "success") {
                        if((result.data).length > 0) {
                            $.each(result.data, function(key, row) {
                                let htmlContent = '';
                                htmlContent = "<div class='row' rowId='"+ row.id +"' style='display:none'><div class='title'><div class='title-left'><img class='imgLogo' src='"+ row.logoUrl +"'></div><div class='title-right'>"+ row.title +"</div><div style='clear:both;'></div></div><div class='location'><span class='companyName'>"+ row.company +"</span><span>"+ row.location +"</span></div><div class='date'>Updated on "+ row.date +"</div></div>";

                                // $("#listContainer").append(htmlContent);
                                $("#loaderDiv").before(htmlContent);
                            }); 

                            pageNo++;
                        }
                    } else {
                        alert('Error occured, please try afer sometime');
                    }
                }
            },
            complete: function(){
                callListAjax = true;
                $(".row").fadeIn('slow');
                $('#loaderDiv').hide();

                $("#jobList .row").unbind( "click", getDetails);
                $("#jobList .row").bind( "click", getDetails);
            }
        });
    }

    $("#jobList").scroll(function(e){
        e.preventDefault();
        let position = $("#jobList").scrollTop();
        let listHeight = $("#listContainer").height();
        let bottom = listHeight - 600;

        if( position >= bottom && callListAjax){                    
            if (position == bottom) {
                $('#loaderDiv').show();
                ajaxCall(pageNo);
            } else{
                $(".product:last").after('<tr id="remove"><td colspan="4" style="text-align: center;"><b>No Data Available</b></td></tr>');
            }
        }
    });
    
    // on page load get records 
    $('#loaderDiv').show();
    setTimeout(function () { ajaxCall(pageNo) }, 500);            
});